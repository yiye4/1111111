#!/bin/bash
# luajit_fetch_and_install.sh
# @version    160830:4
# @author     karminski <code.karminski@outlook.com>
# 
# @changes    161226:4    CHANGE luajit to v2.1-20161104
#             160830:4    CHANGE luajit to v2.1-20160517

# [manual config area]
LUAJIT_PATH=/usr
LUAJIT_INSTALLER_PATH=/data/apps/luajit

source_luajit=https://github.com/openresty/luajit2/archive/v2.1-20161104.tar.gz
untar_folder=luajit2-2.1-20161104

# run

mkdir /data/apps/luajit
cd ${LUAJIT_INSTALLER_PATH}
wget ${source_luajit}

for i in `ls *.tar.gz`
do 
    tar -zxvf $i
done

cd ${untar_folder}

echo -e "\n---------------------------------------------------------------------\n"  
echo -e "FETCH FINISH\n\n"  

sed -i 's/export PREFIX= \/usr\/local/export PREFIX= \/data\/apps\/luajit/g' Makefile

make -j

make install

echo -e "\n---------------------------------------------------------------------\n"  
echo -e "INSTALL FINISH\n\n"  

# if want debug luajit use: make CCDEBUG=-g