#!/bin/bash
# for_centos7.sh
# @version    160830:2
# @author     karminski <code.karminski@outlook.com>
# 

yum install -q pcre-devel.x86_64 openssl-devel.x86_64 wget gcc g++