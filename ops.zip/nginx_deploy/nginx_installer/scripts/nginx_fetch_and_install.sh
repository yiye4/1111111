#!/bin/bash
# nginx_fetch_and_install.sh
# @version    161226:4
# @author     karminski <code.karminski@outlook.com>
# 
# @changes    161226:4    CHANGE nginx to 1.10.2
#             160816:3    CHANGE nginx to 1.10.1

# [manual config area]
LUAJIT_PATH=/data/apps/luajit
NGINX_INSTALLER_PATH=/data/apps/nginx_deploy/nginx_installer
NGINX_PATH=/data/apps/nginx

source_nginx=http://nginx.org/download/nginx-1.10.2.tar.gz
source_ngx_devel_kit=https://github.com/simpl/ngx_devel_kit/archive/v0.3.0.tar.gz
source_lua_nginx_module=https://github.com/openresty/lua-nginx-module/archive/v0.10.7.tar.gz

nginx=nginx-1.10.2
ngx_devel_kit=ngx_devel_kit-0.3.0
lua_nginx_module=lua-nginx-module-0.10.7

# fetch

cd ${NGINX_INSTALLER_PATH}
wget ${source_nginx}
wget ${source_ngx_devel_kit}
wget ${source_lua_nginx_module}

for i in `ls *.tar.gz`
do 
    tar -zxvf $i
done

echo -e "\n---------------------------------------------------------------------\n"  
echo -e "FETCH FINISH\n\n"  

sleep 2

# install
cd ${NGINX_INSTALLER_PATH}

export LUAJIT_LIB=${LUAJIT_PATH}/lib
export LUAJIT_INC=${LUAJIT_PATH}/include/luajit-2.1


echo "config LUAJIT_LIB to ${LUAJIT_LIB} " 
echo "config LUAJIT_INC to ${LUAJIT_INC} "
echo -e "\n\n"  

# configure nginx
cd "${NGINX_INSTALLER_PATH}/${nginx}"

chmod +x ./configure

make clean

./configure --prefix=${NGINX_PATH} \
        --with-debug \
        --with-ld-opt="-Wl,-rpath,${LUAJIT_LIB}" \
        --with-stream \
        --with-stream_ssl_module \
        --with-http_ssl_module \
        --with-http_gunzip_module \
        --with-http_gzip_static_module \
        --with-http_stub_status_module \
        --add-module=${NGINX_INSTALLER_PATH}/${ngx_devel_kit} \
        --add-module=${NGINX_INSTALLER_PATH}/${lua_nginx_module} \

make -j && make install

export PATH=$PATH:${NGINX_PATH}/sbin

echo -e "\n---------------------------------------------------------------------\n"  
echo -e "INSTALL FINISH\n\n"  
