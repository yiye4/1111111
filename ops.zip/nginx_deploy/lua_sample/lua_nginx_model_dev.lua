-- lua_nginx_model_dev.lua

local lua_nginx_model_dev = function()


    local h                  = {}

    local self               = {}
    self.sock                = {}

    -- construct()
    -- @param    nil
    -- @return   nil
    self.construct = function()
        self.sock = assert(ngx.req.socket(true))
    end

    -- run()
    -- @param    nil
    -- @return   nil
    self.run = function()
        while true do
            local data, err = self.sock:receive()
            -- socket error
            if err then
                self:socket_error()
                break
            end
            -- run server
            local dict = ngx.shared.dict
            dict:set("k1", "v1")
            local value = dict:get("k1")
            ngx.say(value)
        end
    end

    self:construct()

    return self

end

local lua_nginx_model_dev = lua_nginx_model_dev()
lua_nginx_model_dev:run()