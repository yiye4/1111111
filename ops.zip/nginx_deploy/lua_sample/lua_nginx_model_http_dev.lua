-- lua_nginx_model_http_dev.lua

local lua_nginx_model_http_dev = function()


    local h                  = {}

    local self               = {}
    self.dict                = nil

    -- run()
    -- @param    nil
    -- @return   nil
    self.run_1 = function()
        -- run server
        self.dict = ngx.shared.dict
        for i=1,100 do
            self.dict:set("k_"..i, i)
        end
        local keys, pointer = self.dict:get_keys(10, 10)
        self.print_r(keys)
        self.print_r(pointer)

    end

    self.print_r = function(t, return_t)
        local tableList = {}
        function table_r (t, name, indent, full)
            local id = not full and name
                or type(name)~="number" and tostring(name) or '['..name..']'
            local tag = indent .. id .. ' = '
            local out = {}  -- result
            if type(t) == "table" then
                if tableList[t] ~= nil then table.insert(out, tag .. '{} -- ' .. tableList[t] .. ' (self reference)')
                else
                    tableList[t]= full and (full .. '.' .. id) or id
                    if next(t) then -- Table not empty
                        table.insert(out, tag .. '{')
                        for key,value in pairs(t) do
                            table.insert(out,table_r(value,key,indent .. '    ',tableList[t]))
                        end
                        table.insert(out,indent .. '}')
                    else table.insert(out,tag .. '{}') end
                end
            else
                local val = type(t)~="number" and type(t)~="boolean" and '"'..tostring(t)..'"' or tostring(t)
                table.insert(out, tag .. val)
            end
            return table.concat(out, '\n')
        end
        local result = table_r(t,name or 'Value',indent or '')
        if (return_t) then
            return result
        end
        ngx.say(result)
    end

    self.run_2 = function()
        local shdstr = require("shdstr")
        local rbtree = shdstr.rbtree
        -- compare function
        local cmp = function(s1, s2)
            if s1 > s2 then
                return 1
            elseif s1 < s2 then
                return -1
            else
                return 0
            end 
        end
        local dat = {a=12,b=14}
        local success, msg = rbtree:insert({"key_1", {12, 24}, cmp})
        if not success then
            return ngx.say(msg)
        end
        
    end

    self.run_3 = function()
        local shdstr = require("shdstr")
        local rbtree = shdstr.rbtree
        local cmp = function(s1, s2)
            if s1 > s2 then
                return 1
            elseif s1 < s2 then
                return -1
            else
                return 0
            end 
        end
        local value, msg = rbtree:get({"key_1", cmp})
        if value == nil then
            return ngx.say(msg)
        end
        self.print_r(value)
    end

    self.run_4 = function()

    end


    return self

end

local lua_nginx_model_http_dev = lua_nginx_model_http_dev()
lua_nginx_model_http_dev:run_1()
-- lua_nginx_model_http_dev:run_2()
-- lua_nginx_model_http_dev:run_3()