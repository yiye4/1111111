#!/bin/bash
# for_centos7.sh
# @version    170227:1
# @author     karminski <code.karminski@outlook.com>
# 

yum install -q perl-Digest-SHA
