#!/bin/sh
# go_fetch_and_install.sh
# This script getch go bin source and install.
# @version    170227:1
# @author     zhangxuhong <zhangxuhong@xitu.io>
#

# [config]
echo "-[config]-"

# ----------------------------[manual config here]------------------------------

# necessary:
INSTALL_SRC=/data/apps
INSTALL_SOURCE=https://storage.googleapis.com/golang/go1.8.linux-amd64.tar.gz
DOWNLOAD_TAR_FILE_NAME=go1.8.linux-amd64.tar.gz # same as INSTALL_SOURCE tar file name

# optional:
INSTALL_SOURCE_SHA256_CHECKSUM=53ab94104ee3923e228a2cb2116e5e462ad3ebaeea06ff04463479d7f12d27ca
HTTP_PROXY=http://localhost:8123
GO_WORKSPACE=/data/repo

# ------------------------------------------------------------------------------

echo -e "\033[34mINSTALL_SRC                    = ${INSTALL_SRC}\033[0m"
echo -e "\033[34mINSTALL_SOURCE                 = ${INSTALL_SOURCE}\033[0m"
echo -e "\033[34mDOWNLOAD_TAR_FILE_NAME         = ${DOWNLOAD_TAR_FILE_NAME}\033[0m"
echo -e "\033[34mINSTALL_SOURCE_SHA256_CHECKSUM = ${INSTALL_SOURCE_SHA256_CHECKSUM}\033[0m"
echo -e "\033[34mHTTP_PROXY                     = ${HTTP_PROXY}\033[0m"
echo -e "\033[34mGO_WORKSPACE                   = ${GO_WORKSPACE}\033[0m"
echo ""
sleep 1

# [fetch source]
echo "-[fetch source]-"
if [ "$http_proxy" !=  "" ]; then 
    echo "http_proxy set to:"
    echo -e "\033[34m${http_proxy}\033[0m";
    echo "http_proxy location info:"
    proxyLocation=`http_proxy=${http_proxy} curl -s ip.gs `
    echo -e "\033[34m${proxyLocation}\033[0m";
    echo "http_proxy=${HTTP_PROXY} curl -LO ${INSTALL_SOURCE}"
    `http_proxy=${HTTP_PROXY} curl -LO ${INSTALL_SOURCE}`
else
    echo "curl -LO ${INSTALL_SOURCE}"
    `curl -LO ${INSTALL_SOURCE}`
fi
ls -alh "./${DOWNLOAD_TAR_FILE_NAME}"
echo "done."
echo ""
sleep 1

# [check shasum]
if [ "$INSTALL_SOURCE_SHA256_CHECKSUM" != "" ]; then
    echo "-[check shasum]-"
    shaSum=`shasum -a 256 "./${DOWNLOAD_TAR_FILE_NAME}" | awk -F' ' '{print $1}'`
    echo "sha 256 sum is: $shaSum"
    if [ "$INSTALL_SOURCE_SHA256_CHECKSUM" != "$shaSum" ];then
        echo -e "\033[43m[WARRING!] shasum error, script exit. \033[0m"
        exit 1;
    fi
    echo "shasum ok"
    echo ""
    sleep 1
fi

# [deploy]
echo "-[deploy]-"
if [ ! -d $INSTALL_SRC ]; then mkdir $INSTALL_SRC; fi
sudo tar -C $INSTALL_SRC -xvzf $DOWNLOAD_TAR_FILE_NAME
echo ""
echo "files in ${INSTALL_SRC}/go :"
ls -alh "${INSTALL_SRC}/go"
echo "done"
echo ""
sleep 1

# [set env]
echo "-[set env]-"
go_workspace_dir=(
    "${GO_WORKSPACE}/bin"
    "${GO_WORKSPACE}/pkg"
    "${GO_WORKSPACE}/src"
)
export GOROOT="${INSTALL_SRC}/go"
if [ "$GO_WORKSPACE" != "" ]; then
    if [ ! -d $GO_WORKSPACE ]; then mkdir $GO_WORKSPACE; fi
    for path in ${go_workspace_dir[*]};
    do
        if [ ! -d $path ]; then mkdir $path; fi
    done
fi
echo "export PATH=\$PATH:${INSTALL_SRC}/go/bin" >> /etc/profile.d/path.sh
echo "export GOBIN=${GO_WORKSPACE}/bin" >> ~/.bash_profile
echo "export GOPKG=${GO_WORKSPACE}/pkg" >> ~/.bash_profile
echo "export GOSRC=${GO_WORKSPACE}/src" >> ~/.bash_profile
source /etc/profile && source ~/.bash_profile

echo -e "\033[34m PATH   = $PATH \033[0m"
echo -e "\033[34m GOROOT = $GOROOT \033[0m"
echo -e "\033[34m GOBIN  = $GOBIN \033[0m"
echo -e "\033[34m GOPKG  = $GOPKG \033[0m"
echo -e "\033[34m GOSRC  = $GOSRC \033[0m"

echo "done"
echo ""

# [test]
echo "-[test]-"
go version
echo "install finish."
echo ""
exit 0
