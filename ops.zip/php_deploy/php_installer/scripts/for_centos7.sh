#!/bin/bash
# for_centos7.sh
# @version    160920:5
# @author     karminski <code.karminski@outlook.com>
# 

yum install epel-release 

yum install curl

rpm -ivh http://mirrors.sohu.com/fedora-epel/7Server/x86_64/e/epel-release-7-8.noarch.rpm

yum clean all && yum makecache
yum update

yum group install "Development Tools"

yum install -q \
pcre-devel.x86_64 \
openssl-devel.x86_64 \
wget \
gcc \
g++ \
gcc-c++ \
php-mcrypt \
libmcrypt \
libmcrypt-devel\
libxml2-devel.x86_64 \
bzip2-libs.x86_64 \
bzip2-devel.x86_64 \
libcurl.x86_64 \
libcurl-devel.x86_64 \
libjpeg-turbo.x86_64 \
libjpeg-turbo-devel.x86_64 \
libjpeg-turbo-static.x86_64 \
libjpeg-turbo-utils.x86_64 \
libpng.x86_64 \
libpng-devel.x86_64 \
libpng-static.x86_64 \
libXpm.x86_64 \
libXpm-devel.x86_64 \
freetype-devel.x86_64  \
freetype.x86_64 \
gmp.x86_64 \
gmp-devel.x86_64 \
gmp-static.x86_64 \
openldap.x86_64 \
php-ldap.x86_64 \
openldap-devel.x86_64 \
php-mcrypt.x86_64 \
libmcrypt-devel.x86_64 \
libmcrypt.x86_64 \
php-pspell.x86_64 \
readline-devel.x86_64  \
readline-static.x86_64  \
readline.x86_64 \
php-recode.x86_64 \
recode-devel.x86_64 \
recode.x86_64 \
libxslt.x86_64 \
libxslt-devel.x86_64 \
m4.x86_64 \