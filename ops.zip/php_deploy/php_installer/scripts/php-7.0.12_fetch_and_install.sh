#!/bin/bash
# php-7.0.12_fetch_and_install.sh
# @version    161017:5
# @author     karminski <code.karminski@outlook.com>
# 

# [manual config area]
INSTALLER_PATH=/data/apps/src/php_deploy/php_installer 
install_source=http://cn2.php.net/get/php-7.0.12.tar.gz/from/this/mirror
untar_folder=php-7.0.12
install_path=/data/apps/php7
config_file_path=/data/apps/php7/etc
fpm_user=www-data
fpm_user_group=www-data

# add user 
# 
adduser www-data

# run

mkdir ${install_path}
mkdir ${config_file_path}
mkdir ${config_file_path}/cli
mkdir ${config_file_path}/cli/conf.d
mkdir ${config_file_path}/fpm
mkdir ${config_file_path}/fpm/conf.d
mkdir ${config_file_path}/fpm/pool.d
mkdir ${config_file_path}/mods-available

cd ${INSTALLER_PATH}
wget ${install_source}

mv mirror php-7.0.12.tar.gz

for i in `ls *.tar.gz`
do 
    tar -zxvf $i
done

cd ${untar_folder}

echo -e "\n---------------------------------------------------------------------\n"  
echo -e "FETCH FINISH\n\n"  

echo -e "\n---------------------------------------------------------------------\n"  
echo -e "NOW INSTALL PHP-CLI\n\n"  

make clean

./configure \
--prefix=${install_path} \
--with-config-file-path=${config_file_path}/cli \
--with-config-file-scan-dir=${config_file_path}/cli/conf.d \
--with-mysqli \
--with-pdo-mysql \
--with-pdo-sqlite \
--with-iconv \
--with-gmp \
--with-xmlrpc \
--with-openssl \
--with-mhash \
--with-mcrypt \
--with-xsl \
--with-curl \
--with-pcre-regex \
--with-gd \
--with-jpeg-dir=/usr \
--with-png-dir=/usr \
--with-zlib-dir=/usr \
--with-xpm-dir=/usr \
--with-freetype-dir=/usr \
--with-gettext=/usr \
--with-zlib=/usr \
--with-bz2=/usr \
--with-recode=/usr \
--with-pear \
--with-readline \
--with-mysqli=mysqlnd \
--with-pdo-mysql=mysqlnd \
--with-gd \
--with-iconv \
--with-zlib \
--with-jpeg-dir \
--with-freetype-dir \
--enable-opcache \
--enable-pdo \
--enable-sockets \
--enable-exif \
--enable-soap \
--enable-ftp \
--enable-wddx \
--enable-pcntl \
--enable-bcmath \
--enable-mbstring \
--enable-dba \
--enable-gd-native-ttf \
--enable-gd-jis-conv \
--enable-zip \
--enable-calendar \
--enable-shmop \
--enable-sysvmsg \
--enable-sysvsem \
--enable-sysvshm \
--enable-inline-optimization \
--enable-session \


make -j

make install

make clean

echo -e "\n---------------------------------------------------------------------\n"  
echo -e "NOW INSTALL PHP-FPM\n\n"  

./configure \
--prefix=${install_path} \
--with-config-file-path=${config_file_path}/fpm \
--with-config-file-scan-dir=${config_file_path}/fpm/conf.d \
--with-fpm-user=${fpm_user} \
--with-fpm-group=${fpm_user_group} \
--with-mysqli \
--with-pdo-mysql \
--with-pdo-sqlite \
--with-iconv \
--with-gmp \
--with-xmlrpc \
--with-openssl \
--with-mhash \
--with-mcrypt \
--with-xsl \
--with-curl \
--with-pcre-regex \
--with-gd \
--with-jpeg-dir=/usr \
--with-png-dir=/usr \
--with-zlib-dir=/usr \
--with-xpm-dir=/usr \
--with-freetype-dir=/usr \
--with-gettext=/usr \
--with-zlib=/usr \
--with-bz2=/usr \
--with-recode=/usr \
--with-pear \
--with-readline \
--with-mysqli=mysqlnd \
--with-pdo-mysql=mysqlnd \
--with-gd \
--with-iconv \
--with-zlib \
--with-jpeg-dir \
--with-freetype-dir \
--disable-cli \
--enable-fpm \
--enable-opcache \
--enable-pdo \
--enable-sockets \
--enable-exif \
--enable-soap \
--enable-ftp \
--enable-wddx \
--enable-pcntl \
--enable-bcmath \
--enable-mbstring \
--enable-dba \
--enable-gd-native-ttf \
--enable-gd-jis-conv \
--enable-zip \
--enable-calendar \
--enable-shmop \
--enable-sysvmsg \
--enable-sysvsem \
--enable-sysvshm \
--enable-inline-optimization \
--enable-session \


make -j

make install

make clean


echo -e "\n---------------------------------------------------------------------\n"  
echo -e "DO CONFIG\n\n"  

cp php.ini-production ${config_file_path}/cli/php.ini
cp php.ini-production ${config_file_path}/fpm/php.ini

# create init.d scripts
cp sapi/fpm/init.d.php-fpm /etc/init.d/php7-fpm
sed -i 's/php_fpm_CONF=\${prefix}\/etc\/php-fpm.conf/php_fpm_CONF=\${prefix}\/etc\/fpm\/php-fpm.conf/' /etc/init.d/php7-fpm
chmod +x /etc/init.d/php7-fpm

# config php-fpm.conf
sed -i 's/php_fpm_CONF=\${prefix}\/etc\/php-fpm.conf/php_fpm_CONF=\${prefix}\/etc\/fpm\/php-fpm.conf/' ${config_file_path}/php-fpm.conf.default
sed -i 's/include=\/data\/apps\/php7\/etc\/php-fpm\.d\/\*\.conf/\;include/' ${config_file_path}/php-fpm.conf.default
cp ${config_file_path}/php-fpm.conf.default ${config_file_path}/fpm/php-fpm.conf
cp ${config_file_path}/php-fpm.d/www.conf.default ${config_file_path}/fpm/pool.d/www.conf
echo "include=${config_file_path}/fpm/pool.d/*.conf" > ${config_file_path}/fpm/php-fpm.conf

echo "zend_extension=opcache.so" > ${config_file_path}/mods-available/opcache.ini
echo "extension=redis.so"        > ${config_file_path}/mods-available/redis.ini

ln -s ${config_file_path}/mods-available/opcache.ini   ${config_file_path}/cli/conf.d/
ln -s ${config_file_path}/mods-available/redis.ini     ${config_file_path}/cli/conf.d/

ln -s ${config_file_path}/mods-available/opcache.ini   ${config_file_path}/fpm/conf.d/
ln -s ${config_file_path}/mods-available/redis.ini     ${config_file_path}/fpm/conf.d/

export PATH=$PATH:${install_path}/bin

echo -e "\n---------------------------------------------------------------------\n"  
echo -e "INSTALL PECL uitls\n\n"  

pecl install redis

echo -e "\n---------------------------------------------------------------------\n"  
echo -e "INSTALL FINISH\n\n"  
